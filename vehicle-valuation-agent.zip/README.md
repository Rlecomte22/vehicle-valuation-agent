# Vehicle Valuation Agent

This repository contains a deployment-ready **frontend (React + Vite + Tailwind)** and **backend (FastAPI)**.

## Deploy
- **Frontend**: Vercel (Root Directory: `/frontend`, Build: `npm run build`, Output: `dist`)
- **Backend**: Render (Root Directory: `/backend`, Start Command: `uvicorn main:app --host 0.0.0.0 --port 10000`)

### Env
Copy `backend/.env.template` to `backend/.env` and add your provider keys when you have them.

### Frontend API URL
Set `VITE_API_BASE` in Vercel Project → Settings → Environment Variables to your Render URL (e.g. `https://YOUR-APP.onrender.com`).
